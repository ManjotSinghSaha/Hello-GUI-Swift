//
//  ViewController.swift
//  Greetings App
//
//  Created by Manjot Singh Saha on 2020-06-30.
//  Copyright © 2020 Manjot Singh Saha. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var textFirstName: UITextField!
    @IBOutlet weak var textLastName: UITextField!
    @IBOutlet weak var outputResult: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func btnFullName(_ sender: UIButton) {
        var firstName = textFirstName.text!
        var lastName = textLastName.text!
        var fullName: String = firstName + " " + lastName
        
        outputResult.text = fullName
    }
    
    
}

